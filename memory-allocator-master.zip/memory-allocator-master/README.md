<p align="center">
  <img src="screenshots/3.png?raw=true"/>
</p>

<p align="center">
  <h1 align="center"> Operating Systems Memory Allocation Simulator </h1>
</p>

<p align="center">
  <b>The memory simulator</b> that <i>you kept searching for</i>.
</p>

<p align="center">
  <b>
    <a href="memory-allocator-gui-app/">Source Code</a>
 - <a href="screenshots/">Screenshots</a>
 - <a href="os-memory-allocator-documentation.pdf">Documentation</a>
 - <a href="https://github.com/BoulaZa5/os-memory-allocator-gui-app/releases">Releases</a>
  </b>
</p>
